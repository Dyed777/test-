﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Note
{
    public partial class MainForm : Form
    {
        private Dictionary<string, string> notes = new Dictionary<string, string>();

        public MainForm()
        {
            InitializeComponent();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            NoteForm noteForm = new NoteForm();
            noteForm.Owner = this;
            noteForm.FormClosed += (s, args) => UpdateNoteList();
            noteForm.ShowDialog();
        }

        private void BtnOpen_Click(object sender, EventArgs e)
        {
            if (listBoxNotes.SelectedIndex != -1)
            {
                string noteTitle = listBoxNotes.SelectedItem.ToString();
                string noteText = GetNoteText(noteTitle);
                ViewNoteForm viewNoteForm = new ViewNoteForm(noteTitle, noteText);
                viewNoteForm.ShowDialog();
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (listBoxNotes.SelectedIndex != -1)
            {
                string noteTitle = listBoxNotes.SelectedItem.ToString();
                DeleteNote(noteTitle);
                UpdateNoteList();
            }
        }

        private string GetNoteText(string noteTitle)
        {
            if (notes.ContainsKey(noteTitle))
            {
                return notes[noteTitle];
            }
            else
            {
                return string.Empty;
            }
        }

        private void DeleteNote(string noteTitle)
        {
            if (notes.ContainsKey(noteTitle))
            {
                notes.Remove(noteTitle);
            }
        }

        private void UpdateNoteList()
        {
            listBoxNotes.Items.Clear();
            foreach (var noteTitle in notes.Keys)
            {
                listBoxNotes.Items.Add(noteTitle);
            }
        }

        public void AddNote(string noteTitle, string noteText)
        {
            notes[noteTitle] = noteText;
            UpdateNoteList();
        }
    }
}