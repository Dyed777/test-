﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Note
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            NoteForm noteForm = new NoteForm();
            noteForm.ShowDialog();
            // Обновление списка заметок
        }

        private void BtnOpen_Click(object sender, EventArgs e)
        {
            if (listBoxNotes.SelectedIndex != -1)
            {
                string noteTitle = listBoxNotes.SelectedItem.ToString();
                string noteText = GetNoteText(noteTitle);
                ViewNoteForm viewNoteForm = new ViewNoteForm(noteTitle, noteText);
                viewNoteForm.ShowDialog();
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (listBoxNotes.SelectedIndex != -1)
            {
                string noteTitle = listBoxNotes.SelectedItem.ToString();
                DeleteNote(noteTitle);
                // Обновление списка заметок
            }
        }

        private string GetNoteText(string noteTitle)
        {
            // Логика получения текста заметки по заголовку
            return "Текст заметки";
        }

        private void DeleteNote(string noteTitle)
        {
            // Логика удаления заметки по заголовку
        }
    }
}