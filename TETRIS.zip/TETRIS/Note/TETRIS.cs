﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Note
{
    public partial class TETRIS : Form
    {
        private Timer gameTimer;
        private int[,] gameGrid;
        private int gridWidth = 10;
        private int gridHeight = 20;
        private int cellSize = 20;
        private int currentX, currentY;
        private int[,] currentPiece;
        private Random random;
        private int score = 0;
        private int level = 1;
        private int linesCleared = 0;
        private const int linesPerLevel = 10;
        private Color[] pieceColors = new Color[]
        {
            Color.Transparent, // Пустота
            Color.Cyan,        // I
            Color.Yellow,      // O
            Color.Purple,      // T
            Color.Green,       // S
            Color.Red,         // Z
            Color.Blue,        // J
            Color.Orange       // L
        };

        public TETRIS()
        {
            InitializeComponent();
            InitializeGame();
        }

        private void InitializeGame()
        {
            gameGrid = new int[gridWidth, gridHeight];
            random = new Random();
            currentPiece = GetRandomPiece();
            currentX = gridWidth / 2 - currentPiece.GetLength(1) / 2;
            currentY = 0;

            gameTimer = new Timer();
            gameTimer.Interval = 500; // 500 миллисекунд
            gameTimer.Tick += GameTimer_Tick;
            gameTimer.Start();

            this.KeyDown += TETRIS_KeyDown;
            this.Paint += TETRIS_Paint;
            this.DoubleBuffered = true;
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            MovePieceDown();
        }

        private void TETRIS_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Left:
                    MovePieceLeft();
                    break;
                case Keys.Right:
                    MovePieceRight();
                    break;
                case Keys.Down:
                    MovePieceDown();
                    break;
                case Keys.Up:
                    RotatePiece();
                    break;
            }
        }

        private void TETRIS_Paint(object sender, PaintEventArgs e)
        {
            DrawGameGrid(e.Graphics);
        }

        private void DrawGameGrid(Graphics g)
        {
            for (int x = 0; x < gridWidth; x++)
            {
                for (int y = 0; y < gridHeight; y++)
                {
                    if (gameGrid[x, y] != 0)
                    {
                        using (Brush brush = new SolidBrush(pieceColors[gameGrid[x, y]]))
                        {
                            g.FillRectangle(brush, x * cellSize, y * cellSize, cellSize, cellSize);
                        }
                        g.DrawRectangle(Pens.Black, x * cellSize, y * cellSize, cellSize, cellSize);
                    }
                }
            }

            for (int i = 0; i < currentPiece.GetLength(0); i++)
            {
                for (int j = 0; j < currentPiece.GetLength(1); j++)
                {
                    if (currentPiece[i, j] != 0)
                    {
                        using (Brush brush = new SolidBrush(pieceColors[currentPiece[i, j]]))
                        {
                            g.FillRectangle(brush, (currentX + j) * cellSize, (currentY + i) * cellSize, cellSize, cellSize);
                        }
                        g.DrawRectangle(Pens.Black, (currentX + j) * cellSize, (currentY + i) * cellSize, cellSize, cellSize);
                    }
                }
            }

            // Отрисовка счета и уровня
            using (Font font = new Font("Arial", 12, FontStyle.Bold))
            {
                g.DrawString($"Score: {score}", font, Brushes.White, 10, 10);
                g.DrawString($"Level: {level}", font, Brushes.White, 10, 30);
            }
        }

        private void MovePieceDown()
        {
            if (CanMove(currentPiece, currentX, currentY + 1))
            {
                currentY++;
            }
            else
            {
                PlacePiece();
                if (IsGameOver())
                {
                    HandleGameOver();
                }
                else
                {
                    currentPiece = GetRandomPiece();
                    currentX = gridWidth / 2 - currentPiece.GetLength(1) / 2;
                    currentY = 0;
                }
            }
            Invalidate();
        }

        private void MovePieceLeft()
        {
            if (CanMove(currentPiece, currentX - 1, currentY))
            {
                currentX--;
                Invalidate();
            }
        }

        private void MovePieceRight()
        {
            if (CanMove(currentPiece, currentX + 1, currentY))
            {
                currentX++;
                Invalidate();
            }
        }

        private void RotatePiece()
        {
            int[,] rotatedPiece = new int[currentPiece.GetLength(1), currentPiece.GetLength(0)];
            for (int i = 0; i < currentPiece.GetLength(0); i++)
            {
                for (int j = 0; j < currentPiece.GetLength(1); j++)
                {
                    rotatedPiece[j, currentPiece.GetLength(0) - 1 - i] = currentPiece[i, j];
                }
            }

            if (CanMove(rotatedPiece, currentX, currentY))
            {
                currentPiece = rotatedPiece;
                Invalidate();
            }
        }

        private bool CanMove(int[,] piece, int newX, int newY)
        {
            for (int i = 0; i < piece.GetLength(0); i++)
            {
                for (int j = 0; j < piece.GetLength(1); j++)
                {
                    if (piece[i, j] != 0)
                    {
                        int gridX = newX + j;
                        int gridY = newY + i;

                        if (gridX < 0 || gridX >= gridWidth || gridY >= gridHeight || (gridY >= 0 && gameGrid[gridX, gridY] != 0))
                        {
                            return false;
                        }
                    }
                }
            }
            return true;
        }

        private void PlacePiece()
        {
            for (int i = 0; i < currentPiece.GetLength(0); i++)
            {
                for (int j = 0; j < currentPiece.GetLength(1); j++)
                {
                    if (currentPiece[i, j] != 0)
                    {
                        gameGrid[currentX + j, currentY + i] = currentPiece[i, j];
                    }
                }
            }

            CheckLines();
        }

        private void CheckLines()
        {
            for (int y = gridHeight - 1; y >= 0; y--)
            {
                bool isFull = true;
                for (int x = 0; x < gridWidth; x++)
                {
                    if (gameGrid[x, y] == 0)
                    {
                        isFull = false;
                        break;
                    }
                }

                if (isFull)
                {
                    for (int yy = y; yy > 0; yy--)
                    {
                        for (int x = 0; x < gridWidth; x++)
                        {
                            gameGrid[x, yy] = gameGrid[x, yy - 1];
                        }
                    }
                    y++;
                    linesCleared++;
                    score += 100 * level; // Увеличиваем счет на 100 очков за каждую линию

                    if (linesCleared >= linesPerLevel)
                    {
                        linesCleared = 0;
                        level++;
                        gameTimer.Interval = Math.Max(100, gameTimer.Interval - 50); // Увеличиваем скорость игры
                    }
                }
            }
        }

        private bool IsGameOver()
        {
            for (int x = 0; x < gridWidth; x++)
            {
                if (gameGrid[x, 0] != 0)
                {
                    return true;
                }
            }
            return false;
        }

        private void HandleGameOver()
        {
            gameTimer.Stop();
            MessageBox.Show("Game Over! Your score: " + score, "Game Over", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }

        private int[,] GetRandomPiece()
        {
            int pieceType = random.Next(7);
            switch (pieceType)
            {
                case 0: // I
                    return new int[,] { { 1, 1, 1, 1 } };
                case 1: // O
                    return new int[,] { { 2, 2 }, { 2, 2 } };
                case 2: // T
                    return new int[,] { { 0, 3, 0 }, { 3, 3, 3 } };
                case 3: // S
                    return new int[,] { { 0, 4, 4 }, { 4, 4, 0 } };
                case 4: // Z
                    return new int[,] { { 5, 5, 0 }, { 0, 5, 5 } };
                case 5: // J
                    return new int[,] { { 6, 0, 0 }, { 6, 6, 6 } };
                case 6: // L
                    return new int[,] { { 0, 0, 7 }, { 7, 7, 7 } };
                default:
                    return new int[,] { { 1 } };
            }
        }
    }
}