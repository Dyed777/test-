﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace Note
{
    public partial class NoteForm : Form
    {
        private TextBox textBoxTitle;
        private RichTextBox richTextBoxNote;

        public NoteForm()
        {
            InitializeComponent();
        }

        private void NoteForm_Load(object sender, EventArgs e)
        {
            // Инициализация элементов управления
            textBoxTitle = new TextBox();
            textBoxTitle.Name = "textBoxTitle";
            textBoxTitle.Location = new System.Drawing.Point(12, 10);
            textBoxTitle.Size = new System.Drawing.Size(200, 20);
            textBoxTitle.ForeColor = System.Drawing.Color.Gray;
            textBoxTitle.Text = "Введите заголовок заметки";
            textBoxTitle.Enter += TextBoxTitle_Enter;
            textBoxTitle.Leave += TextBoxTitle_Leave;
            textBoxTitle.KeyDown += TextBoxTitle_KeyDown; // Добавляем обработчик события KeyDown
            this.Controls.Add(textBoxTitle);

            richTextBoxNote = new RichTextBox();
            richTextBoxNote.Name = "richTextBoxNote";
            richTextBoxNote.Location = new System.Drawing.Point(12, 34);
            richTextBoxNote.Size = new System.Drawing.Size(260, 175);
            this.Controls.Add(richTextBoxNote);

            Button btnSave = new Button();
            btnSave.Text = "SAVE";
            btnSave.Location = new System.Drawing.Point(103, 226);
            btnSave.Click += BtnSave_Click;
            this.Controls.Add(btnSave);
        }

        private void TextBoxTitle_Enter(object sender, EventArgs e)
        {
            if (textBoxTitle.Text == "Введите заголовок заметки")
            {
                textBoxTitle.Text = "";
                textBoxTitle.ForeColor = System.Drawing.Color.Black;
            }
        }

        private void TextBoxTitle_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxTitle.Text))
            {
                textBoxTitle.Text = "Введите заголовок заметки";
                textBoxTitle.ForeColor = System.Drawing.Color.Gray;
            }
        }

        private void TextBoxTitle_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && textBoxTitle.Text.ToUpper() == "TETRIS")
            {
                e.Handled = true; // Предотвращаем стандартное поведение Enter (например, переход на новую строку)
                OpenTetrisForm();
            }
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            string noteTitle = textBoxTitle.Text;
            string noteText = richTextBoxNote.Text;

            if (!string.IsNullOrWhiteSpace(noteTitle) && !string.IsNullOrWhiteSpace(noteText))
            {
                // Сохранение заметки
                MainForm mainForm = (MainForm)this.Owner;
                mainForm.AddNote(noteTitle, noteText);

                this.Close();
            }
            else
            {
                MessageBox.Show("Пожалуйста, введите заголовок и текст заметки.");
            }
        }

        private void OpenTetrisForm()
        {
            TETRIS tetrisForm = new TETRIS();
            tetrisForm.ShowDialog();
        }
    }
}