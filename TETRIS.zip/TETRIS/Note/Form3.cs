﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Note
{
    public partial class ViewNoteForm : Form
    {
        public ViewNoteForm(string noteTitle, string noteText)
        {
            InitializeComponent();
            Label.Text = noteTitle;
            RichTextBox.Text = noteText;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}